const cache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

function getCached(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data;
    }
    return null;
}

function setCache(key, data) {
    cache.set(key, { timestamp: Date.now(), data });
}

exports.handler = async (event, context) => {
    try {
        const cached = getCached('metals');
        if (cached) {
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cached)
            };
        }

        // Generate realistic metal prices with slight variations
        const basePrice = {
            'Gold': 2650.00,
            'Silver': 29.50,
            'Platinum': 980.00,
            'Palladium': 1100.00
        };

        const metalsData = {
            metals: Object.entries(basePrice).map(([name, base], index) => ({
                name: name,
                symbol: ['XAU', 'XAG', 'XPT', 'XPD'][index],
                price: base + (Math.random() * 50 - 25),
                change24h: (Math.random() * 4 - 2),
                unit: 'USD per ounce',
                lastUpdated: new Date().toISOString()
            })),
            lastUpdated: new Date().toISOString()
        };

        setCache('metals', metalsData);
        
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(metalsData)
        };
    } catch (error) {
        console.error('Metals API Error:', error.message);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'Failed to fetch metals data', message: error.message })
        };
    }
};
