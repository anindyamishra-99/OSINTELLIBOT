const axios = require('axios');
const Parser = require('rss-parser');

const parser = new Parser();

// Cache for rate limiting
const cache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

function getCached(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data;
    }
    return null;
}

function setCache(key, data) {
    cache.set(key, { timestamp: Date.now(), data });
}

exports.handler = async (event, context) => {
    try {
        const cached = getCached('news');
        if (cached) {
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(cached)
            };
        }

        const rssFeeds = [
            // Major International News (English)
            { name: 'BBC World', url: 'http://feeds.bbci.co.uk/news/world/rss.xml' },
            { name: 'Reuters World', url: 'http://feeds.reuters.com/reuters/worldNews' },
            { name: 'Al Jazeera English', url: 'https://www.aljazeera.com/xml/rss.xml' },
            { name: 'AP News', url: 'https://apnews.com/rss/news' },
            { name: 'CNN World', url: 'http://rss.cnn.com/rss/cnn_world.rss' },
            { name: 'The Guardian World', url: 'https://www.theguardian.com/world/rss' },
            { name: 'NY Times', url: 'https://rss.nytimes.com/services/xml/rss/nyt/World.xml' },
            { name: 'Washington Post', url: 'https://feeds.washingtonpost.com/rss/world' },
            
            // Iran News (English)
            { name: 'Iran International EN', url: 'https://www.iranintl.com/rss/news/iran' },
            { name: 'Iran Wire EN', url: 'https://iranwire.com/rss' },
            { name: 'Tehran Times', url: 'https://www.tehrantimes.com/rss' },
            
            // Ukraine News (English)
            { name: 'Kyiv Independent', url: 'https://kyivindependent.com/rss' },
            { name: 'Ukraine Pravda EN', url: 'https://www.pravda.com.ua/rss' },
            
            // Russia News (English)
            { name: 'Meduza English', url: 'https://meduza.io/rss/en' },
            { name: 'Moscow Times EN', url: 'https://www.themoscowtimes.com/rss/news' },
            
            // China News (English)
            { name: 'SCMP', url: 'https://www.scmp.com/rss/feed/2/news.xml' },
            { name: 'China Daily', url: 'https://www.chinadaily.com.cn/rss//world.rss' },
            
            // Latin America (English)
            { name: 'Latin America Report', url: 'https://latinamericareport.org/feed' },
            
            // Middle East (English)
            { name: 'Syria Direct EN', url: 'https://syriadirect.org/feed' },
            { name: 'Iraq News EN', url: 'https://www.iraqnews.com/rss' },
            
            // Africa (English)
            { name: 'AllAfrica', url: 'https://allafrica.com/rss/world' },
            { name: 'Somalia News EN', url: 'https://www.hiiraan.com/rss' },
            
            // Asia (English)
            { name: 'Pakistan Dawn EN', url: 'https://www.dawn.com/rss/news' },
            { name: 'India Express EN', url: 'https://indianexpress.com/rss/' },
            { name: 'Taiwan News EN', url: 'https://www.taiwannews.com.tw/feed' },
            { name: 'Thailand Post EN', url: 'https://www.bangkokpost.com/rss/news' },
            { name: 'North Korea News EN', url: 'https://www.nknews.org/feed' },
            
            // UN and International Organizations (True OSINT - English)
            { name: 'UN News', url: 'https://news.un.org/en/rss-feeds' },
            { name: 'US State Dept', url: 'https://www.state.gov/rss-feeds' },
            { name: 'WHO News', url: 'https://www.who.int/rss/en' },
            
            // Think Tanks and Analysis (English)
            { name: 'Crisis Group', url: 'https://www.crisisgroup.org/rss-0' },
            { name: 'Chatham House', url: 'https://www.chathamhouse.org/rss-feeds' },
            { name: 'ECFR', url: 'https://ecfr.eu/feeds/' },
            { name: 'Carnegie Endowment', url: 'https://carnegieendowment.org/rss' },
            { name: 'Brookings Institution', url: 'https://www.brookings.edu/feed' },
            
            // Global Voices (English)
            { name: 'Global Voices', url: 'https://globalvoices.org/feeds/' }
        ];

        const newsPromises = rssFeeds.map(async (feed) => {
            try {
                const feedData = await parser.parseURL(feed.url);
                return feedData.items.slice(0, 5).map(item => ({
                    title: item.title,
                    summary: item.contentSnippet || item.content || '',
                    source: feed.name,
                    pubDate: item.isoDate || item.pubDate,
                    link: item.link,
                    categories: item.categories || []
                }));
            } catch (error) {
                console.error(`Error fetching ${feed.name}:`, error.message);
                return [];
            }
        });

        const results = await Promise.all(newsPromises);
        let allNews = results.flat().sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
        
        // Only filter out .edu sources and truly non-English content
        const unwantedPatterns = [
            /\.edu$/i,
            /\.edu\//i,
            '/feed',
            'university',
            'college',
            'academic',
            'research',
            'harvard',
            'stanford',
            'mit.edu',
            'yale',
            'princeton',
            // Spam and inappropriate content patterns
            'seduction',
            'dating',
            'romance',
            'relationship advice',
            'horoscope',
            'astrology',
            'lottery',
            'prize winner',
            'clickbait',
            'viral trend',
            'blogspot',
            'wordpress.com',
            'medium.com',
            'tumblr',
            'pinterest',
            'substack.com'
        ];
        
        // Only filter content that actually starts with non-Latin characters
        const nonLatinStart = /^[^\u0041-\u005A\u0061-\u007A\u00C0-\u00FF\u0100-\u017F\u0180-\u024F]/;
        
        allNews = allNews.filter(item => {
            const source = item.source || '';
            const title = item.title || '';
            const link = item.link || '';
            
            // Check for unwanted sources
            if (unwantedPatterns.some(pattern => {
                if (typeof pattern === 'string') {
                    return source.toLowerCase().includes(pattern.toLowerCase()) || 
                           link.toLowerCase().includes(pattern.toLowerCase());
                }
                return pattern.test(source) || pattern.test(link);
            })) {
                return false;
            }
            
            // Only exclude if title starts with non-Latin characters
            if (nonLatinStart.test(title.trim())) {
                return false;
            }
            
            return true;
        });
        
        const newsData = {
            news: allNews.slice(0, 50),
            lastUpdated: new Date().toISOString(),
            sources: rssFeeds.map(f => f.name)
        };
        
        setCache('news', newsData);
        
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newsData)
        };
    } catch (error) {
        console.error('News API Error:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: 'Failed to fetch news', message: error.message })
        };
    }
};
